package medicare_admin;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Login_admin_page {
	@FindBy(xpath="//*[@id=\"username\"] ")
			public static WebElement Email;
			@FindBy(xpath="//*[@id=\"password\"]") 
			public static WebElement Password;
			@FindBy(xpath="//*[@id=\"loginForm\"]/div[3]/div/input[2]" ) 
			public static WebElement Login;
			@FindBy(xpath="//*[@id=\"manageProduct\"]/a") 
			public static WebElement Manage_Product;
			}
			


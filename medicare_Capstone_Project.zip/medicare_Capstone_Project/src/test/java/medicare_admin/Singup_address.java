package medicare_admin;

public class Singup_address {
public static final String Address_Line_Two = null;
public static final String Postal_Code = null;
public static final String Address = null;
public static final String Country = null;
public static final String State = null;
public static final String City = null;
public static final String Address_line_one = null;
public void Address_line_one()
{
	
}
public void Address_Line_Two()
{
}
}

package medicare_admin_test;

public class Signup_address {
	public class Singup_address {
		public final String Address_Line_Two = null;
		public final String Postal_Code = null;
		public  final String Address = null;
		public  final String Country = null;
		public  final String State = null;
		public  final String City = null;
		public final String Address_line_one = null;
}
}